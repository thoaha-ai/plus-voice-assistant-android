package com.plus.voiceassistant.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.plus.voiceassistant.databinding.ActivityEnrollSpeakerBinding
import com.plus.voiceassistant.speaker.SpeakerEnrollmentManager
import kotlinx.coroutines.launch

class EnrollSpeakerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEnrollSpeakerBinding
    private lateinit var enrollment: SpeakerEnrollmentManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEnrollSpeakerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        enrollment = SpeakerEnrollmentManager(this) { msg ->
            runOnUiThread { binding.tvDebug.text = msg }
        }

        binding.btnRecordSample.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (!hasAudioPerm()) {
                        Toast.makeText(this, "Need RECORD_AUDIO", Toast.LENGTH_SHORT).show()
                        return@setOnTouchListener true
                    }
                    lifecycleScope.launch { enrollment.startSample() }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    lifecycleScope.launch { enrollment.stopSample() }
                    true
                }
                else -> false
            }
        }

        binding.btnSave.setOnClickListener {
            val name = binding.etName.text?.toString()?.trim().orEmpty()
            if (name.isBlank()) {
                Toast.makeText(this, "Enter a name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                val ok = enrollment.saveSpeaker(name)
                Toast.makeText(
                    this@EnrollSpeakerActivity,
                    if (ok) "Saved $name" else "Need at least 3 samples",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun hasAudioPerm(): Boolean {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }
}
