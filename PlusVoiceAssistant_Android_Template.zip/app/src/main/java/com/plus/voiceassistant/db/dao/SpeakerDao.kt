package com.plus.voiceassistant.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import com.plus.voiceassistant.db.entities.Speaker
import com.plus.voiceassistant.db.entities.SpeakerEmbedding
import com.plus.voiceassistant.db.relations.SpeakerWithEmbeddings

@Dao
interface SpeakerDao {
    @Insert
    suspend fun insertSpeaker(speaker: Speaker): Long

    @Insert
    suspend fun insertEmbeddings(embeddings: List<SpeakerEmbedding>)

    @Transaction
    @Query("SELECT * FROM speakers")
    suspend fun getAllSpeakersWithEmbeddings(): List<SpeakerWithEmbeddings>
}
