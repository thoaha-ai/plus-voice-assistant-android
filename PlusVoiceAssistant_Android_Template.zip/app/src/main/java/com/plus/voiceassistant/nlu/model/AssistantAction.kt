package com.plus.voiceassistant.nlu.model

sealed class AssistantAction(
    val type: Type,
    val arg1: String = "",
    val arg2: String = "",
    val message: String = "",
    val requiresConfirm: Boolean = false
) {
    enum class Type { UNKNOWN, BLOCKED, TIME, DATE, OPEN_APP, TIMER, ALARM, CALL, SMS, WHATSAPP }

    fun withRequiresConfirm(v: Boolean): AssistantAction = when (this) {
        is Call -> Call(who, v)
        is Sms -> Sms(who, text, v)
        is WhatsApp -> WhatsApp(who, text, v)
        else -> this
    }

    class Unknown : AssistantAction(Type.UNKNOWN)
    class Blocked(msg: String) : AssistantAction(Type.BLOCKED, message = msg)

    class Time : AssistantAction(Type.TIME)
    class Date : AssistantAction(Type.DATE)

    class OpenApp(pkg: String) : AssistantAction(Type.OPEN_APP, arg1 = pkg)

    class Timer(minutes: String) : AssistantAction(Type.TIMER, arg1 = minutes)
    class Alarm(hhmm: String) : AssistantAction(Type.ALARM, arg1 = hhmm)

    class Call(val who: String, requiresConfirm: Boolean = false) :
        AssistantAction(Type.CALL, arg1 = who, requiresConfirm = requiresConfirm)

    class Sms(val who: String, val text: String, requiresConfirm: Boolean = false) :
        AssistantAction(Type.SMS, arg1 = who, arg2 = text, requiresConfirm = requiresConfirm)

    class WhatsApp(val who: String, val text: String, requiresConfirm: Boolean = false) :
        AssistantAction(Type.WHATSAPP, arg1 = who, arg2 = text, requiresConfirm = requiresConfirm)
}
