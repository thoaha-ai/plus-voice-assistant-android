package com.plus.voiceassistant.speaker

import android.content.Context
import com.plus.voiceassistant.db.AppDatabase
import com.plus.voiceassistant.speaker.model.SpeakerMatch
import kotlin.math.sqrt

/**
 * Template speaker recognizer.
 * In production: run a TFLite embedding model -> vector, then cosine similarity.
 * Here: we use a deterministic hash-based fake embedding to keep the app runnable.
 */
class SpeakerRecognizer(context: Context) {

    private val db = AppDatabase.get(context)

    suspend fun identify(pcm16: ShortArray, threshold: Float): SpeakerMatch {
        val speakers = db.speakerDao().getAllSpeakersWithEmbeddings()
        if (speakers.isEmpty()) return SpeakerMatch(false, "Unknown", 0f)

        val emb = fakeEmbedding(pcm16)
        var bestName = "Unknown"
        var bestScore = -1f

        for (s in speakers) {
            for (e in s.embeddings) {
                val score = cosine(emb, e.vector)
                if (score > bestScore) {
                    bestScore = score
                    bestName = s.speaker.name
                }
            }
        }

        val known = bestScore >= threshold
        val isOwner = bestName.equals("owner", ignoreCase = true) || bestName.equals("thoaha", ignoreCase = true)
        return SpeakerMatch(known, if (known) bestName else "Unknown", bestScore, isOwner)
    }

    private fun fakeEmbedding(pcm16: ShortArray): FloatArray {
        // Very simple deterministic "embedding" (NOT real speaker ID)
        // Replace with TFLite model output.
        val out = FloatArray(64)
        var acc = 0L
        for (i in pcm16.indices step 160) {
            acc = (acc * 1315423911L) xor pcm16[i].toLong()
        }
        for (i in out.indices) {
            val v = ((acc shr (i % 16)) and 0xFFFF).toInt()
            out[i] = (v / 65535f)
        }
        return out
    }

    private fun cosine(a: FloatArray, b: FloatArray): Float {
        val n = minOf(a.size, b.size)
        var dot = 0f
        var na = 0f
        var nb = 0f
        for (i in 0 until n) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        val denom = sqrt(na) * sqrt(nb)
        return if (denom == 0f) 0f else dot / denom
    }
}
