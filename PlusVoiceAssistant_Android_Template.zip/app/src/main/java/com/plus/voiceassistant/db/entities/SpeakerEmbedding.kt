package com.plus.voiceassistant.db.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "speaker_embeddings",
    foreignKeys = [
        ForeignKey(
            entity = Speaker::class,
            parentColumns = ["id"],
            childColumns = ["speakerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("speakerId")]
)
data class SpeakerEmbedding(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val speakerId: Long,
    val vector: FloatArray,
    val createdAt: Long = System.currentTimeMillis()
)
