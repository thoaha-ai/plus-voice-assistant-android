package com.plus.voiceassistant.speaker.model

data class SpeakerMatch(
    val isKnown: Boolean,
    val name: String,
    val score: Float,
    val isOwner: Boolean = false
)
