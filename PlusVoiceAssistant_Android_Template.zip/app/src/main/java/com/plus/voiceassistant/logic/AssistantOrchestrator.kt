package com.plus.voiceassistant.logic

import android.content.Context
import com.plus.voiceassistant.logic.model.AssistantUIState
import com.plus.voiceassistant.nlu.IntentParser
import com.plus.voiceassistant.nlu.model.AssistantAction
import com.plus.voiceassistant.speaker.SpeakerRecognizer
import com.plus.voiceassistant.stt.SttEngine
import com.plus.voiceassistant.tts.TtsManager
import com.plus.voiceassistant.util.AppPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Coordinates: audio -> speaker -> STT -> intent -> action -> reply -> TTS
 *
 * NOTE: This template uses a fake STT engine by default (returns placeholder text).
 * Replace SttEngine implementation with whisper.cpp JNI for real offline STT.
 */
class AssistantOrchestrator(
    private val context: Context,
    private val onUi: (AssistantUIState) -> Unit
) {
    private val prefs = AppPrefs(context)
    private val recorder = PushToTalkRecorder(context)
    private val stt: SttEngine = SttEngine.Fake()
    private val speaker = SpeakerRecognizer(context)
    private val parser = IntentParser()
    private val actions = SystemActions(context)
    private val tts = TtsManager(context)

    private var lastTranscript: String = ""
    private var lastSpeakerName: String = "Unknown"

    suspend fun startPushToTalk() = withContext(Dispatchers.IO) {
        recorder.start()
        onUi(AssistantUIState(lastSpeakerName, lastTranscript, "Listening..."))
    }

    suspend fun stopPushToTalkAndProcess() = withContext(Dispatchers.IO) {
        val pcm = recorder.stopAndGetPcm16()
        if (pcm == null || pcm.isEmpty()) {
            onUi(AssistantUIState(lastSpeakerName, lastTranscript, "No audio captured"))
            return@withContext
        }

        // 1) speaker
        val spk = speaker.identify(pcm, prefs.speakerThreshold)
        lastSpeakerName = spk.name

        // 2) STT
        val transcript = stt.transcribePcm16(pcm, sampleRateHz = 16000)
        lastTranscript = transcript
        onUi(AssistantUIState(lastSpeakerName, transcript, "Processing..."))

        // 3) NLU
        val action = parser.parse(transcript)

        // 4) enforce speaker safety
        val safeAction = SafetyPolicy.enforce(context, spk, action)

        // 5) Execute + reply
        val result = actions.execute(safeAction)
        val reply = result.replyText
        onUi(AssistantUIState(lastSpeakerName, transcript, reply))
        tts.speak(reply)
    }
}
