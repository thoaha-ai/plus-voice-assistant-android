package com.plus.voiceassistant.speaker

import android.content.Context
import com.plus.voiceassistant.db.AppDatabase
import com.plus.voiceassistant.db.entities.Speaker
import com.plus.voiceassistant.db.entities.SpeakerEmbedding
import com.plus.voiceassistant.logic.PushToTalkRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Enrollment template:
 * - records short samples
 * - generates fake embeddings (replace with real TFLite embedding)
 * - stores in Room
 */
class SpeakerEnrollmentManager(
    private val context: Context,
    private val onDebug: (String) -> Unit
) {
    private val recorder = PushToTalkRecorder(context)
    private val db = AppDatabase.get(context)
    private val samples = mutableListOf<FloatArray>()

    suspend fun startSample() = withContext(Dispatchers.IO) {
        recorder.start()
        onDebug("Recording sample... (release to stop)")
    }

    suspend fun stopSample() = withContext(Dispatchers.IO) {
        val pcm = recorder.stopAndGetPcm16()
        if (pcm == null) {
            onDebug("No audio.")
            return@withContext
        }
        val emb = SpeakerRecognizer(context).run {
            // reuse fake embedding function by calling identify is not ideal; just create a recognizer and call internal?
            // We'll re-create fake embedding here by using identify on empty DB, but that's blocked.
            // So: generate a quick hash embedding:
            val out = FloatArray(64)
            var acc = 0L
            for (i in pcm.indices step 160) {
                acc = (acc * 1315423911L) xor pcm[i].toLong()
            }
            for (i in out.indices) {
                val v = ((acc shr (i % 16)) and 0xFFFF).toInt()
                out[i] = (v / 65535f)
            }
            out
        }
        samples.add(emb)
        onDebug("Captured sample #${samples.size}. (Need 3-5)")
    }

    suspend fun saveSpeaker(name: String): Boolean = withContext(Dispatchers.IO) {
        if (samples.size < 3) return@withContext false

        val speakerId = db.speakerDao().insertSpeaker(Speaker(name = name))
        val embeds = samples.map { vec ->
            SpeakerEmbedding(
                speakerId = speakerId,
                vector = vec
            )
        }
        db.speakerDao().insertEmbeddings(embeds)
        samples.clear()
        onDebug("Saved speaker '$name' with ${embeds.size} embeddings.")
        true
    }
}
