package com.plus.voiceassistant.stt

/**
 * STT interface for offline transcription.
 * Replace Fake() with whisper.cpp JNI implementation.
 */
interface SttEngine {
    fun transcribePcm16(pcm16: ShortArray, sampleRateHz: Int): String

    class Fake : SttEngine {
        override fun transcribePcm16(pcm16: ShortArray, sampleRateHz: Int): String {
            // TODO: plug whisper.cpp JNI. For now, returns placeholder.
            return "Placeholder transcript (replace with whisper.cpp). Try: 'Rahim কে কল দাও — but STT not wired yet.'"
        }
    }
}
