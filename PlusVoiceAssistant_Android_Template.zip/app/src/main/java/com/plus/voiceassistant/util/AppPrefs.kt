package com.plus.voiceassistant.util

import android.content.Context

class AppPrefs(context: Context) {
    private val sp = context.getSharedPreferences("pva_prefs", Context.MODE_PRIVATE)

    var alwaysOnEnabled: Boolean
        get() = sp.getBoolean("always_on", false)
        set(v) = sp.edit().putBoolean("always_on", v).apply()

    var allowTrustedSpeakersCallSms: Boolean
        get() = sp.getBoolean("allow_trusted", false)
        set(v) = sp.edit().putBoolean("allow_trusted", v).apply()

    var speakerThreshold: Float
        get() = sp.getFloat("spk_th", 0.75f)
        set(v) = sp.edit().putFloat("spk_th", v.coerceIn(0f, 1f)).apply()
}
