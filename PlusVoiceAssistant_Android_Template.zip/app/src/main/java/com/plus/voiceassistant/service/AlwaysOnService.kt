package com.plus.voiceassistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.plus.voiceassistant.R
import com.plus.voiceassistant.logic.HotwordLoop
import com.plus.voiceassistant.util.AppPrefs

class AlwaysOnService : Service() {

    companion object {
        @Volatile var isRunning: Boolean = false
        private const val CHANNEL_ID = "plus_voice_assistant_channel"
        private const val NOTIF_ID = 1001
    }

    private var loop: HotwordLoop? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        ensureChannel()
        startForeground(NOTIF_ID, buildNotification("Listening for hotword..."))

        loop = HotwordLoop(applicationContext)
        loop?.start()
    }

    override fun onDestroy() {
        loop?.stop()
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CHANNEL_ID, "Plus Voice Assistant", NotificationManager.IMPORTANCE_LOW)
            mgr.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Plus Voice Assistant")
            .setContentText(text)
            .setOngoing(true)
            .build()
    }
}
