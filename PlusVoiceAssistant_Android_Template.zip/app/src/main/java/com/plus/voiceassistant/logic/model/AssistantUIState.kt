package com.plus.voiceassistant.logic.model

data class AssistantUIState(
    val speakerName: String,
    val transcript: String,
    val reply: String
)
