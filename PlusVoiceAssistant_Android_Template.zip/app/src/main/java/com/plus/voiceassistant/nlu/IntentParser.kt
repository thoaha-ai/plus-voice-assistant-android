package com.plus.voiceassistant.nlu

import com.plus.voiceassistant.nlu.model.AssistantAction
import java.util.Locale

/**
 * Simple rule-based parser (Bangla + English).
 * Replace/extend with better NLU later.
 */
class IntentParser {

    fun parse(text: String): AssistantAction {
        val t = text.trim()
        if (t.isEmpty()) return AssistantAction.Unknown()

        val lower = t.lowercase(Locale.getDefault())

        // Time/date
        if (lower.contains("সময়") || lower.contains("time")) return AssistantAction.Time()
        if (lower.contains("তারিখ") || lower.contains("date")) return AssistantAction.Date()

        // Timer: "10 মিনিট" / "timer 10 minutes"
        val timerBn = Regex("(\d+)\s*মিনিট")
        val timerEn = Regex("timer\s*(for\s*)?(\d+)\s*(min|mins|minute|minutes)")
        timerBn.find(lower)?.let { return AssistantAction.Timer(it.groupValues[1]) }
        timerEn.find(lower)?.let { return AssistantAction.Timer(it.groupValues[2]) }

        // Alarm: expect HH:MM
        val alarmBn = Regex("(\d{1,2}):(\d{2}).*(অ্যালার্ম|alarm)")
        val alarmEn = Regex("(set\s*)?alarm\s*(for\s*)?(\d{1,2}):(\d{2})")
        alarmBn.find(lower)?.let { return AssistantAction.Alarm("${it.groupValues[1]}:${it.groupValues[2]}") }
        alarmEn.find(lower)?.let { return AssistantAction.Alarm("${it.groupValues[3]}:${it.groupValues[4]}") }

        // Call: "X কে কল দাও" / "call X"
        val callBn = Regex("(.+?)\s*(কে)?\s*(কল দাও|ফোন দাও|কল করো)")
        val callEn = Regex("(call|dial)\s+(.+)")
        callBn.matchEntire(lower)?.let { return AssistantAction.Call(it.groupValues[1].trim()) }
        callEn.find(lower)?.let { return AssistantAction.Call(it.groupValues[2].trim()) }

        // WhatsApp explicit
        if (lower.contains("whatsapp") || lower.contains("হোয়াটসঅ্যাপ") || lower.contains("হোয়াটসঅ্যাপ")) {
            // "whatsapp X: text" or "WhatsApp এ X কে লিখে দাও—text"
            val w1 = Regex("whatsapp\s+(.+?)[:\-]\s*(.+)")
            w1.find(t)?.let { return AssistantAction.WhatsApp(it.groupValues[1].trim(), it.groupValues[2].trim()) }

            val wBn = Regex("(.+?)\s*(কে)?\s*(লিখে দাও|মেসেজ দাও)\s*[-—:]\s*(.+)")
            wBn.find(t)?.let { return AssistantAction.WhatsApp(it.groupValues[1].trim(), it.groupValues[4].trim()) }

            return AssistantAction.Unknown() // slot filling should handle in v1.1
        }

        // SMS / Message: "X কে মেসেজ দাও—text" / "send sms to X: text"
        val smsEn = Regex("(send\s*)?(sms|text|message)\s*(to\s*)?(.+?)[:\-]\s*(.+)")
        smsEn.find(lower)?.let {
            val who = it.groupValues[4].trim()
            val msg = t.substringAfter(":").substringAfter("-").substringAfter("—").trim()
            return AssistantAction.Sms(who, msg)
        }

        val smsBn = Regex("(.+?)\s*(কে)?\s*(মেসেজ দাও|এসএমএস দাও|মেসেজ করো)\s*[-—:]\s*(.+)")
        smsBn.find(t)?.let { return AssistantAction.Sms(it.groupValues[1].trim(), it.groupValues[4].trim()) }

        return AssistantAction.Unknown()
    }
}
