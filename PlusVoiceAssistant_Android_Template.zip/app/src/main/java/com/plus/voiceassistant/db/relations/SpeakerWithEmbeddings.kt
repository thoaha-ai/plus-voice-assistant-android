package com.plus.voiceassistant.db.relations

import androidx.room.Embedded
import androidx.room.Relation
import com.plus.voiceassistant.db.entities.Speaker
import com.plus.voiceassistant.db.entities.SpeakerEmbedding

data class SpeakerWithEmbeddings(
    @Embedded val speaker: Speaker,
    @Relation(
        parentColumn = "id",
        entityColumn = "speakerId"
    )
    val embeddings: List<SpeakerEmbedding>
)
