package com.plus.voiceassistant.logic

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.delay

/**
 * Simple PCM16 recorder. Records while button is held.
 * Captures at 16kHz mono.
 */
class PushToTalkRecorder(private val context: Context) {

    private val sampleRate = 16000
    private val channel = AudioFormat.CHANNEL_IN_MONO
    private val encoding = AudioFormat.ENCODING_PCM_16BIT

    private var record: AudioRecord? = null
    private val buffer = ArrayList<Short>(sampleRate * 10) // up to ~10 sec by default
    @Volatile private var running = false

    fun start() {
        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channel, encoding).coerceAtLeast(sampleRate)
        record = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            channel,
            encoding,
            minBuf
        )
        buffer.clear()
        running = true
        record?.startRecording()

        val tmp = ShortArray(minBuf / 2)
        Thread {
            while (running) {
                val n = record?.read(tmp, 0, tmp.size) ?: 0
                if (n > 0) {
                    for (i in 0 until n) buffer.add(tmp[i])
                }
            }
        }.start()
    }

    fun stopAndGetPcm16(): ShortArray? {
        running = false
        try {
            record?.stop()
        } catch (_: Throwable) {}
        try {
            record?.release()
        } catch (_: Throwable) {}
        record = null

        if (buffer.isEmpty()) return null
        val out = ShortArray(buffer.size)
        for (i in buffer.indices) out[i] = buffer[i]
        return out
    }
}
