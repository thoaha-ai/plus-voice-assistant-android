package com.plus.voiceassistant.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.plus.voiceassistant.db.entities.Note

@Dao
interface NoteDao {
    @Insert
    suspend fun insert(note: Note): Long

    @Query("SELECT * FROM notes ORDER BY createdAt DESC LIMIT 100")
    suspend fun latest(): List<Note>
}
