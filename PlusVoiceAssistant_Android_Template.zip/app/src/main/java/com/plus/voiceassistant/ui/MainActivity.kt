package com.plus.voiceassistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.plus.voiceassistant.databinding.ActivityMainBinding
import com.plus.voiceassistant.logic.AssistantOrchestrator
import com.plus.voiceassistant.service.AlwaysOnService
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var orchestrator: AssistantOrchestrator

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val denied = perms.filterValues { !it }.keys
        if (denied.isNotEmpty()) {
            Toast.makeText(this, "Permissions denied: $denied", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Permissions granted", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        orchestrator = AssistantOrchestrator(this) { ui ->
            runOnUiThread {
                binding.tvSpeaker.text = "Speaker: ${ui.speakerName}"
                binding.tvTranscript.text = ui.transcript.ifBlank { "..." }
                binding.tvReply.text = ui.reply.ifBlank { "..." }
            }
        }

        requestNeededPermissions()

        binding.btnEnroll.setOnClickListener {
            startActivity(Intent(this, EnrollSpeakerActivity::class.java))
        }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnToggleAlwaysOn.setOnClickListener {
            toggleAlwaysOnService()
        }

        // Push-to-talk: hold to record
        binding.btnPushToTalk.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lifecycleScope.launch { orchestrator.startPushToTalk() }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    lifecycleScope.launch { orchestrator.stopPushToTalkAndProcess() }
                    true
                }
                else -> false
            }
        }
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        val perms = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS
        )
        for (p in perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needed.add(p)
            }
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun toggleAlwaysOnService() {
        val intent = Intent(this, AlwaysOnService::class.java)
        if (AlwaysOnService.isRunning) {
            stopService(intent)
            Toast.makeText(this, "Always-on stopped", Toast.LENGTH_SHORT).show()
        } else {
            ContextCompat.startForegroundService(this, intent)
            Toast.makeText(this, "Always-on started", Toast.LENGTH_SHORT).show()
        }
    }
}
