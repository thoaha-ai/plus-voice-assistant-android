package com.plus.voiceassistant.db

import androidx.room.TypeConverter
import java.nio.ByteBuffer
import java.nio.ByteOrder

class Converters {
    @TypeConverter
    fun floatArrayToBytes(arr: FloatArray): ByteArray {
        val bb = ByteBuffer.allocate(4 * arr.size).order(ByteOrder.LITTLE_ENDIAN)
        for (v in arr) bb.putFloat(v)
        return bb.array()
    }

    @TypeConverter
    fun bytesToFloatArray(bytes: ByteArray): FloatArray {
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val n = bytes.size / 4
        val out = FloatArray(n)
        for (i in 0 until n) out[i] = bb.float
        return out
    }
}
