package com.plus.voiceassistant.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.plus.voiceassistant.db.dao.NoteDao
import com.plus.voiceassistant.db.dao.SpeakerDao
import com.plus.voiceassistant.db.entities.Note
import com.plus.voiceassistant.db.entities.Speaker
import com.plus.voiceassistant.db.entities.SpeakerEmbedding

@Database(
    entities = [Speaker::class, SpeakerEmbedding::class, Note::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun speakerDao(): SpeakerDao
    abstract fun noteDao(): NoteDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "plus_voice_assistant.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
