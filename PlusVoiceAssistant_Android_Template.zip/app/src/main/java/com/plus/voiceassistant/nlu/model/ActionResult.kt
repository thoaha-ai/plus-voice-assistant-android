package com.plus.voiceassistant.nlu.model

data class ActionResult(
    val replyText: String
)
