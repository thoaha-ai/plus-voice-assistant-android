package com.plus.voiceassistant.logic

import android.content.Context
import com.plus.voiceassistant.nlu.model.AssistantAction
import com.plus.voiceassistant.speaker.model.SpeakerMatch
import com.plus.voiceassistant.util.AppPrefs

object SafetyPolicy {
    fun enforce(context: Context, speaker: SpeakerMatch, action: AssistantAction): AssistantAction {
        val prefs = AppPrefs(context)
        val risky = action.type == AssistantAction.Type.CALL || action.type == AssistantAction.Type.SMS || action.type == AssistantAction.Type.WHATSAPP

        if (!risky) return action

        // Unknown speaker: block risky actions
        if (!speaker.isKnown) {
            return AssistantAction.Blocked("Unknown speaker cannot Call/SMS.")
        }

        // Trusted speakers gate
        if (!prefs.allowTrustedSpeakersCallSms && !speaker.isOwner) {
            return AssistantAction.Blocked("Only owner can Call/SMS. Enable 'Allow trusted speakers' in Settings.")
        }

        // Risky action always needs confirm; confirmation handled in UI/state machine (v1.1)
        // For this template, we auto-require confirmation and block if not provided.
        // You can implement full confirmation dialog + voice confirm in v1.1.
        return action.withRequiresConfirm(true)
    }
}
