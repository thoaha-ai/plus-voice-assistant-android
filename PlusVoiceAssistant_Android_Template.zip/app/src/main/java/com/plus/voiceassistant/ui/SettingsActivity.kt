package com.plus.voiceassistant.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.plus.voiceassistant.databinding.ActivitySettingsBinding
import com.plus.voiceassistant.util.AppPrefs

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = AppPrefs(this)

        binding.swAlwaysOn.isChecked = prefs.alwaysOnEnabled
        binding.swAllowTrusted.isChecked = prefs.allowTrustedSpeakersCallSms
        binding.sbThreshold.progress = (prefs.speakerThreshold * 100).toInt().coerceIn(0, 100)
        binding.tvThresholdLabel.text = "Speaker threshold: %.2f".format(prefs.speakerThreshold)

        binding.swAlwaysOn.setOnCheckedChangeListener { _, isChecked ->
            prefs.alwaysOnEnabled = isChecked
        }
        binding.swAllowTrusted.setOnCheckedChangeListener { _, isChecked ->
            prefs.allowTrustedSpeakersCallSms = isChecked
        }
        binding.sbThreshold.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress / 100f
                prefs.speakerThreshold = v
                binding.tvThresholdLabel.text = "Speaker threshold: %.2f".format(v)
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
    }
}
