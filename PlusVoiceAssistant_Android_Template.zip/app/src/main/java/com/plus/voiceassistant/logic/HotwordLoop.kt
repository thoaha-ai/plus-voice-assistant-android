package com.plus.voiceassistant.logic

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import com.plus.voiceassistant.ui.MainActivity
import com.plus.voiceassistant.util.AppPrefs
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Minimal hotword loop template.
 * For a fully-free implementation, easiest MVP is STT-based hotword detection on short chunks.
 *
 * This template just keeps the mic alive and does NOT run real hotword detection yet.
 * TODO: Implement:
 *  - record 1.5-2s chunk
 *  - run STT
 *  - if transcript contains "হেই সহকারী" or "hey assistant" -> launch MainActivity
 */
class HotwordLoop(private val context: Context) {

    private val running = AtomicBoolean(false)
    private var record: AudioRecord? = null

    fun start() {
        if (running.getAndSet(true)) return
        val prefs = AppPrefs(context)
        if (!prefs.alwaysOnEnabled) {
            running.set(false)
            return
        }

        val sampleRate = 16000
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(sampleRate)

        record = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            minBuf
        )
        record?.startRecording()

        Thread {
            val buf = ShortArray(minBuf / 2)
            while (running.get()) {
                // Consume audio to keep service active (placeholder).
                record?.read(buf, 0, buf.size)
                try { Thread.sleep(150) } catch (_: Throwable) {}
            }
        }.start()
    }

    fun stop() {
        running.set(false)
        try { record?.stop() } catch (_: Throwable) {}
        try { record?.release() } catch (_: Throwable) {}
        record = null
    }
}
