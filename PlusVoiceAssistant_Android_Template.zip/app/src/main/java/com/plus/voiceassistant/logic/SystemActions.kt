package com.plus.voiceassistant.logic

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.telephony.SmsManager
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.plus.voiceassistant.nlu.model.AssistantAction
import com.plus.voiceassistant.nlu.model.ActionResult
import com.plus.voiceassistant.util.ContactResolver

class SystemActions(private val context: Context) {

    private val resolver = ContactResolver(context)

    fun execute(action: AssistantAction): ActionResult {
        return when (action.type) {
            AssistantAction.Type.BLOCKED -> ActionResult("Blocked: ${action.message}")
            AssistantAction.Type.UNKNOWN -> ActionResult("আমি বুঝতে পারিনি। আবার বলুন।")
            AssistantAction.Type.TIME -> ActionResult(java.time.LocalTime.now().toString())
            AssistantAction.Type.DATE -> ActionResult(java.time.LocalDate.now().toString())
            AssistantAction.Type.OPEN_APP -> openApp(action.arg1)
            AssistantAction.Type.TIMER -> setTimer(action.arg1)
            AssistantAction.Type.ALARM -> setAlarm(action.arg1)
            AssistantAction.Type.CALL -> doCall(action.arg1, action.requiresConfirm)
            AssistantAction.Type.SMS -> doSms(action.arg1, action.arg2, action.requiresConfirm)
            AssistantAction.Type.WHATSAPP -> doWhatsApp(action.arg1, action.arg2, action.requiresConfirm)
        }
    }

    private fun openApp(appName: String): ActionResult {
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(appName)
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionResult("Opening app.")
        } else {
            ActionResult("App not found: $appName. Use package name (e.g., com.google.android.youtube).")
        }
    }

    private fun setTimer(minutesStr: String): ActionResult {
        val minutes = minutesStr.toIntOrNull()
        if (minutes == null || minutes <= 0) return ActionResult("Timer time invalid.")
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return ActionResult("Setting timer for $minutes minutes.")
    }

    private fun setAlarm(timeStr: String): ActionResult {
        // Expect HH:MM (24h) for template
        val parts = timeStr.split(":")
        if (parts.size != 2) return ActionResult("Alarm time format should be HH:MM")
        val h = parts[0].toIntOrNull() ?: return ActionResult("Invalid hour")
        val m = parts[1].toIntOrNull() ?: return ActionResult("Invalid minute")
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, h)
            putExtra(AlarmClock.EXTRA_MINUTES, m)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return ActionResult("Setting alarm for %02d:%02d".format(h, m))
    }

    private fun doCall(nameOrNumber: String, requiresConfirm: Boolean): ActionResult {
        if (requiresConfirm) return ActionResult("Confirm required: Say 'yes' to call $nameOrNumber.")
        val number = resolver.resolvePhoneNumber(nameOrNumber) ?: nameOrNumber
        val canCall = ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val intent = if (canCall) {
            Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
        } else {
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return if (canCall) ActionResult("Calling $nameOrNumber") else ActionResult("Opening dialer for $nameOrNumber")
    }

    private fun doSms(nameOrNumber: String, text: String, requiresConfirm: Boolean): ActionResult {
        if (requiresConfirm) return ActionResult("Confirm required: Say 'yes' to send SMS to $nameOrNumber.")
        val number = resolver.resolvePhoneNumber(nameOrNumber) ?: nameOrNumber
        val canSend = ActivityCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
        return if (canSend) {
            SmsManager.getDefault().sendTextMessage(number, null, text, null, null)
            ActionResult("SMS sent to $nameOrNumber.")
        } else {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$number")
                putExtra("sms_body", text)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResult("Opening messaging app for $nameOrNumber.")
        }
    }

    private fun doWhatsApp(nameOrNumber: String, text: String, requiresConfirm: Boolean): ActionResult {
        if (requiresConfirm) return ActionResult("Confirm required: Say 'yes' to message $nameOrNumber on WhatsApp.")
        // Reliable free flow: open WhatsApp with prefilled text (user taps Send)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://wa.me/?text=${Uri.encode(text)}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.whatsapp")
        }
        return try {
            context.startActivity(intent)
            ActionResult("Opening WhatsApp (prefilled). Select chat and tap Send.")
        } catch (_: Throwable) {
            ActionResult("WhatsApp not installed.")
        }
    }
}
